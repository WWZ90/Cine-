import 'package:cinemania/presentation/providers/providers.dart';
import 'package:cinemania/presentation/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class PersonScreen extends ConsumerStatefulWidget {
  static const name = 'person-screen';
  final int id;
  final String personName;
  final String profilePath;
  final double popularity;
  const PersonScreen({
    super.key,
    required this.id,
    required this.personName,
    required this.profilePath,
    required this.popularity,
  });

  @override
  ConsumerState<PersonScreen> createState() => _PersonScreenState();
}

class _PersonScreenState extends ConsumerState<PersonScreen> {
  @override
  void initState() {
    super.initState();
    ref.read(personDetailsProvider(widget.id).notifier);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: Colors.black,
            expandedHeight: 400,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  LoadImage(
                    h: size.height * 0.55,
                    w: double.infinity,
                    url: widget.profilePath,
                  ),

                  GradientImageBackground(),

                  // Favorite button positioned bottom right
                  // Positioned(
                  //   bottom: 55,
                  //   right: 10,
                  //   child: FavLikeButtonConsumer(
                  //     data: widget.person,
                  //     type: 'Person',
                  //   ),
                  // ),
                ],
              ),
            ),
          ),

          SliverList(
            delegate: SliverChildListDelegate([
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 20,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.personName,
                      style: Theme.of(context).textTheme.headlineMedium
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(Icons.star, size: 16, color: Colors.amber),
                        const SizedBox(width: 4),
                        Text(
                          '${widget.popularity.toStringAsFixed(1)} popularity',
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // if (formatDate(person.birthday))
                    //   Text(
                    //     'Born on ${person.birthday}',
                    //     style: Theme.of(context).textTheme.bodyMedium,
                    //   ),
                    // if (person.placeOfBirth != null)
                    //   Text(
                    //     'in ${person.placeOfBirth}',
                    //     style: Theme.of(context).textTheme.bodyMedium,
                    //   ),
                    // const SizedBox(height: 20),
                    // if (person.biography != null &&
                    //     person.biography!.isNotEmpty)
                    //   Text(
                    //     person.biography!,
                    //     style: Theme.of(context).textTheme.bodyLarge,
                    //     textAlign: TextAlign.justify,
                    //   ),
                    const SizedBox(height: 30),
                    _PersonMoviesSection(personId: widget.id),
                    const SizedBox(height: 30),
                    _PersonTVShowsSection(personId: widget.id),

                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

class _PersonMoviesSection extends ConsumerWidget {
  final int personId;
  const _PersonMoviesSection({required this.personId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final moviesState = ref.watch(moviesByPersonProvider(personId.toString()));

    if (moviesState.isLoading && moviesState.movies.isEmpty) {
      return const Center(child: CircularProgressIndicator(strokeWidth: 2));
    }

    if (!moviesState.isLoading && moviesState.movies.isEmpty) {
      return const Center(child: Text('No movies found'));
    }

    return SliderHorizontalListview(allData: moviesState.movies, type: 'Movie', title: 'Películas',);
  }
}

class _PersonTVShowsSection extends ConsumerWidget {
  final int personId;
  const _PersonTVShowsSection({required this.personId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tvState = ref.watch(tvShowsByPersonProvider(personId.toString()));

    if (tvState.isLoading && tvState.shows.isEmpty) {
      return const Center(child: CircularProgressIndicator(strokeWidth: 2));
    }

    if (!tvState.isLoading && tvState.shows.isEmpty) {
      return const Center(child: Text('No TV shows found'));
    }

    return SliderHorizontalListview(allData: tvState.shows, type: 'TVShow', title: 'Series');
  }
}
