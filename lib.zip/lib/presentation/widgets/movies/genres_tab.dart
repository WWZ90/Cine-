import 'package:cinemania/domain/entities/genre.dart';
import 'package:cinemania/presentation/providers/genres/genres_movies_provider.dart';
import 'package:cinemania/presentation/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class GenresTab extends ConsumerStatefulWidget {
  const GenresTab({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _GenresTabState();
}

class _GenresTabState extends ConsumerState<GenresTab> {
  @override
  Widget build(BuildContext context) {
    final genres = ref.watch(genresMovieProvider);
    return SizedBox(
      height: 200,
      child: DefaultTabController(
        length: genres.length,
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(50),
            child: AppBar(
              bottom: TabBar(
                indicatorColor: Colors.white,
                indicatorSize: TabBarIndicatorSize.tab,
                indicatorWeight: 2.0,
                //unselectedLabelColor: Style.MyColors.titleColor,
                labelColor: Colors.white,
                isScrollable: true,
                tabs:
                    genres.map((Genre genre) {
                      return Container(
                        padding: EdgeInsets.only(bottom: 5),
                        child: Text(genre.name.toUpperCase()),
                      );
                    }).toList(),
              ),
            ),
          ),
          body: TabBarView(
            children: genres.map((Genre genre) {
              return MoviesHorizontalListview(movies: movies);
            }),
          ),
        ),
      ),
    );
  }
}
