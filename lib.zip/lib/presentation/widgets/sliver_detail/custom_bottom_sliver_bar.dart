import 'package:flutter/material.dart';

import '../widgets.dart';

class CustomBottomSliverBar extends StatelessWidget {
  final Size size;
  final num fixRotation;
  final double percent;
  final dynamic data;
  const CustomBottomSliverBar({
    super.key,
    required this.size,
    required this.fixRotation,
    required this.percent,
    required this.data,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: 0,
      left: -size.width * fixRotation.clamp(0, 0.45),
      right: 0,
      child: CustomBottomSliver(size: size, percent: percent, data: data),
    );
  }
}
